"""Модуль с играми."""
from games_project_yuzhakova.VD_games.cli import welcome_user

def main():
    """Главная функция."""
    welcome_user()

if __name__ == "__main__":
    main()
