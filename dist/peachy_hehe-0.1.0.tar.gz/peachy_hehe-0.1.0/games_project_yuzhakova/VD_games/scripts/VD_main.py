"""Главный модуль - точка входа."""
from games_project_yuzhakova.VD_games.scripts.VD_games import main

if __name__ == "__main__":
    main()
